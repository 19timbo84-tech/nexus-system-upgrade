# NEXUS Execution & Continuous Improvement Upgrade — v1

## Purpose

This patch adds a canonical execution layer designed to solve four observed problems:

1. functions that produce no meaningful output;
2. identical outputs across repeated executions;
3. uncontrolled use of `Math.random()` in critical paths;
4. claims of improvement without an objective comparison.

## Core rule

**Different does not mean better.**

Every execution receives a unique execution ID and seed. Variation is controlled and reproducible. Results are validated and scored. A result is marked `NEW_BEST` only when its measured score exceeds the current champion.

## Reality separation

Every input must declare one of:

- `LIVE`
- `CACHED`
- `DERIVED`
- `SIMULATED`
- `SYNTHETIC`
- `UNKNOWN`

No synthetic result may silently become `LIVE`.

## Integration strategy

Do not replace every existing function at once.

For each canonical capability:

1. wrap its current input in `ExecutionInput`;
2. execute through `ExecutionImprovementRuntime`;
3. return the existing domain output unchanged;
4. add metrics;
5. validate output;
6. persist the execution context and output hash;
7. register the capability in `CapabilityRegistry`.

## Mandatory migration

Critical paths should stop calling `Math.random()` directly.

Use:

```ts
const variation = new SeededVariation(context.seed);
const value = variation.next();
```

Only use uncontrolled randomness for explicitly non-critical UI/demo behavior.

## Required evidence

A successful execution should expose:

- `executionId`
- `seed`
- `inputHash`
- `configurationHash`
- `engineVersion`
- `variationProfile`
- `outputHash`
- metrics
- validation status
- improvement score
- parent execution ID when applicable

## Run the proof test

```bash
npx vitest run src/omega/execution/ExecutionImprovementRuntime.test.ts
```

## Run the demonstration

```bash
npx tsx src/omega/execution/scripts/runExecutionImprovement.ts
```

The demonstration must generate different outputs while remaining reproducible from each recorded seed.

## Important limitation

This patch does not magically make every existing NEXUS capability functional. It provides the runtime and contracts needed to audit and upgrade them honestly. Existing mocks, hardcoded datasets, missing handlers, and broken UI paths must still be migrated capability-by-capability.
