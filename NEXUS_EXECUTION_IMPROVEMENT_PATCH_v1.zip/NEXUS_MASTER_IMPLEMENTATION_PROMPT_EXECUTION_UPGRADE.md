# NEXUS — MASTER IMPLEMENTATION PROMPT
## EXECUTION TRUTH + CONTINUOUS IMPROVEMENT + FUNCTIONALITY RECOVERY

You are the senior engineer responsible for upgrading the existing NEXUS repository.

The objective is NOT to add more screens or inflate capability claims.

The objective is to transform NEXUS into a coherent execution platform where every exposed function either:

1. produces a verified meaningful output;
2. explicitly reports PARTIAL/SIMULATED status;
3. or is automatically detected as NO_OUTPUT/BROKEN.

### NON-NEGOTIABLE RULES

1. Never claim a function works unless its complete execution path has been executed.
2. Never treat a different result as an improvement without a measurable quality comparison.
3. Never use uncontrolled `Math.random()` in critical execution, evaluation, scientific, causal, benchmark, reproduction, or provenance paths.
4. Every execution gets a unique `executionId` and a recorded seed.
5. Variation must be controlled and reproducible.
6. Every result gets an `outputHash`.
7. Every input declares `LIVE`, `CACHED`, `DERIVED`, `SIMULATED`, `SYNTHETIC`, or `UNKNOWN`.
8. Synthetic/mock data must never silently acquire LIVE status.
9. Empty/null/undefined outputs are failures, not successes.
10. Existing functionality must not be deleted merely to make tests pass.
11. Do not add placeholder implementations.
12. Do not manufacture data to make a benchmark look better.
13. Preserve backward compatibility where practical.
14. Every repaired function gets a regression test.
15. Prefer canonical shared engines over duplicate command-specific implementations.

### REQUIRED ARCHITECTURE

UI / Command
→ Capability Registry
→ Execution Runtime
→ Input Reality Gate
→ Domain Engine
→ Output Validator
→ Improvement Scorer
→ Provenance / Evidence
→ Result
→ UI

### EXECUTION CONTRACT

Each execution must record:

- executionId
- parentExecutionId when applicable
- seed
- startedAt
- inputHash
- configurationHash
- engineVersion
- variationProfile
- outputHash
- latencyMs
- quality
- completeness
- confidence
- novelty
- errorRate
- validation
- status
- improvement

### CONTINUOUS IMPROVEMENT

For repeated executions:

1. generate controlled variation;
2. execute;
3. validate;
4. calculate quality score;
5. compare against the current champion;
6. retain the new result only as `NEW_BEST` if objectively better;
7. otherwise retain it as history without promoting it;
8. never optimize solely for novelty.

### FUNCTIONALITY AUDIT

Scan all exposed functions and classify them:

- VERIFIED
- PARTIAL
- SIMULATED
- NO_OUTPUT
- BROKEN

For every function, identify:

- UI entry
- handler
- route
- service
- engine
- data source
- output
- renderer
- tests

Detect:

- button with no handler
- handler with no output
- endpoint with no real implementation
- empty response
- hardcoded-only data
- mock-only result
- swallowed exception
- UI result not rendered
- async operation never awaited
- invalid JSON response
- runtime path that silently falls back to synthetic data

### REPAIR PRIORITY

P0:
- broken execution paths
- empty outputs
- misleading LIVE status
- secret exposure
- provenance loss

P1:
- duplicated engines
- uncontrolled randomness
- missing validators
- missing tests

P2:
- UX/navigation consolidation
- performance
- visual polish

P3:
- new capabilities

Do NOT implement P3 work until P0/P1 is under control.

### ACCEPTANCE CRITERIA

The upgrade is successful only when:

- repeated execution produces controlled variation;
- repeated execution is reproducible from recorded seed;
- output quality is measurable;
- improvement is measurable;
- empty output cannot be marked successful;
- reality status survives the complete pipeline;
- every canonical capability has an explicit status;
- tests verify the above;
- reports distinguish repository evidence from freshly executed evidence.

At the end, produce:

1. `FUNCTIONALITY_AUDIT.json`
2. `EXECUTION_CAPABILITY_REGISTRY.json`
3. `EXECUTION_IMPROVEMENT_REPORT.json`
4. test output with exact commands
5. list of repaired functions
6. list of remaining broken/partial functions
7. list of simulated/hardcoded data sources
8. list of uncontrolled randomness remaining
9. before/after execution examples

Never write "production-ready", "verified", "passed", or "improved" unless the corresponding evidence is actually available.
