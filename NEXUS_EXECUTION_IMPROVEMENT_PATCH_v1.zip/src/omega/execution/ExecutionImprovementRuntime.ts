/**
 * NEXUS Execution & Continuous Improvement Runtime
 *
 * Goals:
 * - Every execution receives a unique executionId and seed.
 * - Variation is controlled, reproducible and traceable.
 * - Real, cached, derived, simulated and synthetic inputs remain distinguishable.
 * - Results are validated before being accepted.
 * - Each new execution is compared with the historical champion.
 * - "Improvement" is measurable; randomness alone never counts as improvement.
 */

import { createHash, randomUUID } from "node:crypto";

export type RealityStatus =
  | "LIVE"
  | "CACHED"
  | "DERIVED"
  | "SIMULATED"
  | "SYNTHETIC"
  | "UNKNOWN";

export interface ExecutionContext {
  executionId: string;
  seed: string;
  startedAt: string;
  inputHash: string;
  configurationHash: string;
  engineVersion: string;
  variationProfile: string;
  parentExecutionId?: string;
}

export interface ExecutionInput<T = unknown> {
  data: T;
  realityStatus: RealityStatus;
  source?: string;
  sourceTimestamp?: string;
}

export interface ExecutionMetrics {
  quality: number;
  completeness: number;
  confidence: number;
  novelty: number;
  latencyMs: number;
  errorRate: number;
}

export interface ExecutionResult<T = unknown> {
  context: ExecutionContext;
  output: T;
  outputHash: string;
  metrics: ExecutionMetrics;
  accepted: boolean;
  improvement: number;
  status: "NEW_BEST" | "ACCEPTED" | "REJECTED";
  validation: {
    valid: boolean;
    reasons: string[];
  };
}

export interface ExecutionAttempt<T = unknown> {
  variationProfile: string;
  execute: (
    context: ExecutionContext
  ) => Promise<{
    output: T;
    metrics: Omit<ExecutionMetrics, "latencyMs">;
  }>;
}

function sha256(value: unknown): string {
  const canonical =
    typeof value === "string" ? value : JSON.stringify(value);
  return createHash("sha256").update(canonical ?? "null").digest("hex");
}

/**
 * Small deterministic PRNG. It is intentionally local to an execution.
 * It is not used as a source of truth; it only creates controlled variation.
 */
export class SeededVariation {
  private state: number;

  constructor(seed: string) {
    const digest = sha256(seed).slice(0, 8);
    this.state = parseInt(digest, 16) >>> 0;
  }

  next(): number {
    // Mulberry32
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  pick<T>(values: readonly T[]): T {
    if (!values.length) throw new Error("Cannot pick from an empty collection");
    return values[Math.floor(this.next() * values.length)];
  }
}

export class ExecutionImprovementRuntime {
  private champion?: ExecutionResult;
  private readonly history: ExecutionResult[] = [];

  constructor(
    private readonly engineVersion = "execution-improvement-v1"
  ) {}

  createContext<T>(
    input: ExecutionInput<T>,
    configuration: unknown = {},
    variationProfile = "controlled-default",
    parentExecutionId?: string
  ): ExecutionContext {
    const executionId = randomUUID();
    const seed = sha256(`${executionId}:${Date.now()}:${input.source ?? "unknown"}`);

    return {
      executionId,
      seed,
      startedAt: new Date().toISOString(),
      inputHash: sha256(input.data),
      configurationHash: sha256(configuration),
      engineVersion: this.engineVersion,
      variationProfile,
      parentExecutionId
    };
  }

  validateInput<T>(input: ExecutionInput<T>): string[] {
    const reasons: string[] = [];

    if (input.data === undefined || input.data === null) {
      reasons.push("INPUT_EMPTY");
    }

    if (!input.realityStatus) {
      reasons.push("REALITY_STATUS_MISSING");
    }

    return reasons;
  }

  validateOutput<T>(output: T, metrics: ExecutionMetrics): string[] {
    const reasons: string[] = [];

    if (output === undefined || output === null) {
      reasons.push("OUTPUT_EMPTY");
    }

    for (const [key, value] of Object.entries(metrics)) {
      if (typeof value !== "number" || !Number.isFinite(value)) {
        reasons.push(`METRIC_INVALID:${key}`);
      }
    }

    if (metrics.quality < 0 || metrics.quality > 1) reasons.push("QUALITY_OUT_OF_RANGE");
    if (metrics.completeness < 0 || metrics.completeness > 1) reasons.push("COMPLETENESS_OUT_OF_RANGE");
    if (metrics.confidence < 0 || metrics.confidence > 1) reasons.push("CONFIDENCE_OUT_OF_RANGE");
    if (metrics.novelty < 0 || metrics.novelty > 1) reasons.push("NOVELTY_OUT_OF_RANGE");
    if (metrics.errorRate < 0 || metrics.errorRate > 1) reasons.push("ERROR_RATE_OUT_OF_RANGE");

    return reasons;
  }

  score(metrics: ExecutionMetrics): number {
    // Quality dominates. Novelty is useful but can never overpower poor quality.
    return Number((
      metrics.quality * 0.40 +
      metrics.completeness * 0.20 +
      metrics.confidence * 0.20 +
      metrics.novelty * 0.10 +
      (1 - metrics.errorRate) * 0.10
    ).toFixed(6));
  }

  async execute<T>(
    input: ExecutionInput<T>,
    attempt: ExecutionAttempt<T>,
    configuration: unknown = {},
    parentExecutionId?: string
  ): Promise<ExecutionResult<T>> {
    const inputProblems = this.validateInput(input);
    if (inputProblems.length) {
      throw new Error(`Execution input rejected: ${inputProblems.join(", ")}`);
    }

    const context = this.createContext(
      input,
      configuration,
      attempt.variationProfile,
      parentExecutionId
    );

    const started = Date.now();
    const produced = await attempt.execute(context);
    const latencyMs = Date.now() - started;

    const metrics: ExecutionMetrics = {
      ...produced.metrics,
      latencyMs
    };

    const outputProblems = this.validateOutput(produced.output, metrics);
    const valid = outputProblems.length === 0;

    const result: ExecutionResult<T> = {
      context,
      output: produced.output,
      outputHash: sha256(produced.output),
      metrics,
      accepted: valid,
      improvement: 0,
      status: valid ? "ACCEPTED" : "REJECTED",
      validation: { valid, reasons: outputProblems }
    };

    if (!valid) {
      this.history.push(result);
      return result;
    }

    const currentScore = this.score(metrics);
    const championScore = this.champion ? this.score(this.champion.metrics) : 0;
    result.improvement = Number((currentScore - championScore).toFixed(6));

    if (!this.champion || currentScore > championScore) {
      result.status = "NEW_BEST";
      this.champion = result;
    }

    this.history.push(result);
    return result;
  }

  getChampion(): ExecutionResult | undefined {
    return this.champion;
  }

  getHistory(): readonly ExecutionResult[] {
    return this.history;
  }

  getStatus() {
    const champion = this.champion;
    return {
      executions: this.history.length,
      championExecutionId: champion?.context.executionId ?? null,
      championScore: champion ? this.score(champion.metrics) : null,
      lastExecutionId: this.history.at(-1)?.context.executionId ?? null
    };
  }
}
