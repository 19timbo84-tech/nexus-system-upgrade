/**
 * Central capability registry for execution truth.
 * A capability cannot be reported as VERIFIED unless it has a valid execution path.
 */

import type { RealityStatus } from "./ExecutionImprovementRuntime";

export type CapabilityStatus =
  | "VERIFIED"
  | "PARTIAL"
  | "SIMULATED"
  | "NO_OUTPUT"
  | "BROKEN";

export interface CapabilityRecord {
  id: string;
  name: string;
  entrypoint: string;
  status: CapabilityStatus;
  realityModes: RealityStatus[];
  lastExecutionId?: string;
  lastOutputHash?: string;
  notes?: string[];
}

export class CapabilityRegistry {
  private readonly records = new Map<string, CapabilityRecord>();

  register(record: CapabilityRecord): void {
    this.records.set(record.id, { ...record });
  }

  update(id: string, patch: Partial<CapabilityRecord>): CapabilityRecord {
    const current = this.records.get(id);
    if (!current) throw new Error(`Unknown capability: ${id}`);
    const next = { ...current, ...patch };
    this.records.set(id, next);
    return next;
  }

  get(id: string): CapabilityRecord | undefined {
    return this.records.get(id);
  }

  list(): CapabilityRecord[] {
    return [...this.records.values()];
  }

  summary() {
    const counts: Record<CapabilityStatus, number> = {
      VERIFIED: 0,
      PARTIAL: 0,
      SIMULATED: 0,
      NO_OUTPUT: 0,
      BROKEN: 0
    };

    for (const record of this.records.values()) counts[record.status]++;

    return {
      total: this.records.size,
      counts
    };
  }
}
