import { ExecutionImprovementRuntime, SeededVariation } from "../ExecutionImprovementRuntime";

async function main() {
  const runtime = new ExecutionImprovementRuntime("nexus-execution-improvement-v1");
  const input = {
    data: {
      domain: "demo",
      baseline: 100
    },
    realityStatus: "DERIVED" as const,
    source: "execution-audit-demo"
  };

  for (let i = 0; i < 5; i++) {
    const result = await runtime.execute(
      input,
      async (context) => {
        const variation = new SeededVariation(context.seed);
        const delta = Number(((variation.next() - 0.5) * 20).toFixed(3));
        const value = 100 + delta;

        return {
          output: {
            run: i + 1,
            value,
            seed: context.seed,
            variationProfile: context.variationProfile
          },
          metrics: {
            quality: Math.max(0, Math.min(1, 0.72 + variation.next() * 0.20)),
            completeness: 0.95,
            confidence: 0.75 + variation.next() * 0.20,
            novelty: 0.40 + variation.next() * 0.40,
            errorRate: 0.02
          }
        };
      },
      { run: i + 1 },
      runtime.getStatus().lastExecutionId ?? undefined
    );

    console.log(JSON.stringify({
      executionId: result.context.executionId,
      status: result.status,
      improvement: result.improvement,
      outputHash: result.outputHash,
      metrics: result.metrics
    }, null, 2));
  }

  console.log("=== RUNTIME STATUS ===");
  console.log(JSON.stringify(runtime.getStatus(), null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
