import { describe, expect, it } from "vitest";
import {
  ExecutionImprovementRuntime,
  SeededVariation,
  type ExecutionInput
} from "./ExecutionImprovementRuntime";

describe("ExecutionImprovementRuntime", () => {
  it("creates different execution IDs and seeds", () => {
    const runtime = new ExecutionImprovementRuntime();
    const input: ExecutionInput = {
      data: { value: 10 },
      realityStatus: "DERIVED",
      source: "test"
    };

    const a = runtime.createContext(input);
    const b = runtime.createContext(input);

    expect(a.executionId).not.toBe(b.executionId);
    expect(a.seed).not.toBe(b.seed);
  });

  it("keeps seeded variation reproducible", () => {
    const a = new SeededVariation("seed-A");
    const b = new SeededVariation("seed-A");

    expect([a.next(), a.next(), a.next()]).toEqual([
      b.next(),
      b.next(),
      b.next()
    ]);
  });

  it("accepts a genuinely improved execution as NEW_BEST", async () => {
    const runtime = new ExecutionImprovementRuntime();

    const input: ExecutionInput = {
      data: { value: 10 },
      realityStatus: "DERIVED",
      source: "test"
    };

    const first = await runtime.execute(
      input,
      async () => ({
        output: { answer: "A" },
        metrics: {
          quality: 0.60,
          completeness: 0.70,
          confidence: 0.60,
          novelty: 0.30,
          errorRate: 0
        }
      }),
      { version: 1 }
    );

    const second = await runtime.execute(
      input,
      async () => ({
        output: { answer: "B" },
        metrics: {
          quality: 0.90,
          completeness: 0.90,
          confidence: 0.90,
          novelty: 0.40,
          errorRate: 0
        }
      }),
      { version: 2 },
      first.context.executionId
    );

    expect(first.status).toBe("NEW_BEST");
    expect(second.status).toBe("NEW_BEST");
    expect(second.improvement).toBeGreaterThan(0);
    expect(second.output).not.toEqual(first.output);
  });

  it("rejects empty outputs instead of claiming success", async () => {
    const runtime = new ExecutionImprovementRuntime();

    const result = await runtime.execute(
      {
        data: { value: 1 },
        realityStatus: "SIMULATED"
      },
      async () => ({
        output: null,
        metrics: {
          quality: 0.9,
          completeness: 0.9,
          confidence: 0.9,
          novelty: 0.5,
          errorRate: 0
        }
      })
    );

    expect(result.accepted).toBe(false);
    expect(result.status).toBe("REJECTED");
    expect(result.validation.reasons).toContain("OUTPUT_EMPTY");
  });
});
